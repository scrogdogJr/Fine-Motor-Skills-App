function setup() {
  createCanvas(900, 500);
  background("white");
  
}
function draw() {
//Non-moving objects
  
  //Title box
  fill(255);
  rect(25, 35, 250, 30);
  //Title text
  fill(0);
  textSize(25);
  textStyle(BOLD);
  text("Putting in Contacts", 35, 40, 500);
  
  //Explanation box will appear as soon as the user enters the page
  //Explanation box
  fill("light gray");
  rect(300, 150, 300, 200);
  
  //Explanation Text
  fill(0);
  textSize(15);
  text("In this exercise you will be using the mouse and keyboard to click on, drag over, and insert the contact into the eye while holding the eye open using two of your keys on your keyboard. ", 310, 160, 275);
  //User will be able to click off of the explanation box when they have read the instructions
  
//Moving objects
  
  //Eye
  //The eye will have an object "eyelid" over the top that will have to be held open in order to put the contact in
  fill("white"); 
  circle(765, 150, 150);
  fill('#663300');
  ellipse(700, 150, 20, 75);
  
  //"Table"
  //Purely aesthetic
  fill("tan");
  rect(0, 450, 900, 500);
  
  //Contact
  //Contact will be clicked on and moved to the eye
  let contactX = 100;
  let contactY = 450;
  fill('#CCFFFF');
  ellipse(contactX, contactY, 100, 50);
  
}

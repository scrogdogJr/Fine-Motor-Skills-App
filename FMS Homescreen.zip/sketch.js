let x = 0;
let y = 0;
let name = "Fine Motor Skill Enhancer";
function setup() {
  createCanvas(1000, 600);

  background(255);
}

function draw(){
  //Resets background for moving objects
  background(255);
  
  //Makes Title Box
  stroke(0);
  fill(255);
  rect(22, 22, 350, 35);
  
  //Puts title in box
  fill(0);
  textSize(23);
  text(name, 36, 28, 350, 35);
  
  //Makes description box
  fill("white");
  stroke("blue");
  rect(22, 78, 956, 150);
  
  //Makes activities title box
  stroke(0);
  rect(22, 250, 350, 35);
  
  //Puts in the Activities title in box
  textSize(23);
  fill(0);
  text("Activities", 35, 258, 350, 35);
  
  //Makes Activity 1 box
  fill("white");
  rect(22, 300, 175, 40);
  
  //Puts in Activity 1 title in box
  textSize(15);
  textStyle(NORMAL);
  fill(0);
  text("Activity 1-", 77, 304, 175, 40);
  text("Putting in Contacts", 47, 323, 175, 40);
  
  //Makes Activity 2 box
  fill("white");
  rect(412.5, 300, 175, 40);
  
  //Puts in Activity 2 title in box
  textSize(15);
  textStyle(NORMAL);
  fill(0);
  text("Activity 2-", 468, 304, 175, 40);
  text("Typing", 475, 323, 175, 40);
  
  //Makes Activity 3 box
  fill("white");
  rect(803, 300, 175, 40);
  
  //Puts in Activity 3 title in box
  textSize(15);
  textStyle(NORMAL);
  fill(0);
  text("Activity 3-", 859, 304, 175, 40);
  text("Using Utensils", 845, 323, 175, 40);
  
  fill("white");
  rect(22, 350, 175, 200);
  
  fill("white");
  rect(412.5, 350, 175, 200);
  
  fill("white");
  rect(803, 350, 175, 200);
  
  
  textSize(15);
  fill(0);
  text(x, 50, 550);
  text(y, 50, 565);
  
}



  function mouseClicked(){
    x = mouseX;
    y = mouseY;
  }
//     if(mouseX < 250){
//         x -= 2;
//     }
      
//     if(mouseX > 750){
//         x += 2;
//     }
    
//     if(mouseX >= 250 && mouseX <= 750 && mouseY > 250)
//       y += 2;
    
//     if(mouseX >= 250 && mouseX <= 750 && mouseY < 250)
//       y -= 2;
    
    
//   }
        
      

// function draw(){
//   
  
  
// }

// var position = {
//   y : 0,
  
//   moveShapeY : function(){
    
//     function mouseClicked(){

//     }
//   }
// };

// var position = {
//   x : 1,
//   y : 0,
  
//   moveShape : function() {
    
//     function keyPressed(){
//       if (keyCode == RIGHT_ARROW){
        
//           this.x += 1;
        
//       }
//       else if (keyCode == LEFT_ARROW){
//         while(keyIsPressed == true){
//         }
//           this.x -= 1;
        
//       }
//       else if (keyCode == UP_ARROW){
//         while(keyIsPressed == true){
//         }
//         this.y += 1;
        
//       }
//       else if(keyCode == DOWN_ARROW){
//         while(keyIsPressed == true){   
//         }
//           this.y -= 1;
        
//       } 
//     }
//     return this.x;
//   }
// };